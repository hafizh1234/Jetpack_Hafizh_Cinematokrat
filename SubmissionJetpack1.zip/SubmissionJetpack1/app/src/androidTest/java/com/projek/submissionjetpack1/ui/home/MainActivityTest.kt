package com.projek.submissionjetpack1.ui.home

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import com.projek.submissionjetpack1.R
import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.utils.DataDummy
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4ClassRunner::class)
class MainActivityTest {
    private val dummyTvShow = DataDummy.getTvShow()
    private val dummyMovies = DataDummy.getMovies()
    private val dummyDirector = DataDummy.getDirector()

    @get:Rule
    var activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun loadMovies() {
        onView(withId(R.id.rv_movie)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_movie)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dummyMovies.size - 1
            )
        )
    }

    @Test
    fun loadDetailMovie() {
        onView(withId(R.id.rv_movie)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                click()
            )
        )
        onView(withId(R.id.title_film)).check(matches(isDisplayed()))
        onView(withId(R.id.title_film)).check(matches(withText(dummyMovies[0].title)))
        onView(withId(R.id.rating_film)).check(matches(isDisplayed()))
        onView(withId(R.id.rating_film)).check(matches(withText(dummyMovies[0].rating)))
        onView(withId(R.id.release_date)).check(matches(isDisplayed()))
        onView(withId(R.id.release_date)).check(matches(withText(dummyMovies[0].releaseDate)))
        onView(withId(R.id.description)).check(matches(isDisplayed()))
        onView(withId(R.id.description)).check(matches(withText(dummyMovies[0].description)))
        onView(withId(R.id.rv_genre)).check(matches(isDisplayed()))
        var sizeGenre = dummyMovies[0].genres.split(",").size
        onView(withId(R.id.rv_genre)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                sizeGenre - 1
            )
        )
        onView(withId(R.id.rv_actor)).check(matches(isDisplayed()))
        var size = 0
        val actors = (dummyMovies[0].idActorDirected?.size ?: 0) + 1
        size = if (actors % 2 == 0) {
            actors / 2
        } else {
            actors / 2 + 1
        }
        onView(withId(R.id.rv_actor)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                size
            )
        )
    }

    @Test
    fun loadDetailActor() {
        onView(withId(R.id.rv_movie)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                click()
            )
        )
        onView(withId(R.id.rv_actor)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                MyViewAction.clickChildViewWithId(R.id.linearLayout)
            )
        )
        val directorId = dummyMovies[0].idDirector
        var directorResult = Casting("", "", "", "", "", "", "", "")
        for (director in dummyDirector) {
            if (director.idCaster == directorId) {
                directorResult = director
            }
        }
        onView(withId(R.id.caster_name)).check(matches(isDisplayed()))
        onView(withId(R.id.caster_name)).check(matches(withText(directorResult.nameCaster)))
        onView(withId(R.id.date_and_place_of_birth)).check(matches(isDisplayed()))
        onView(withId(R.id.date_and_place_of_birth)).check(matches(withText("${directorResult.placeOfBirth}\n${directorResult.dateOfBirth}")))
        onView(withId(R.id.casting)).check(matches(isDisplayed()))
        onView(withId(R.id.casting)).check(matches(withText(directorResult.typeCast)))
        onView(withId(R.id.biography_caster)).check(matches(isDisplayed()))
        onView(withId(R.id.biography_caster)).check(matches(withText(directorResult.biographyCaster)))
    }

    @Test
    fun loadTvShow() {
        onView(withText(R.string.tv_show)).perform(click())
        onView(withId(R.id.rv_tv_show)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_tv_show)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dummyTvShow.size - 1
            )
        )
    }
}