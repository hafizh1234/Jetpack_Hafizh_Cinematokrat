package com.projek.submissionjetpack1.data

class Casting(
    var idCaster:String,
    var nameCaster:String,
    var imageCaster:String,
    var biographyCaster:String,
    var gender:String,
    var dateOfBirth:String,
    var placeOfBirth:String,
    var typeCast:String
    //typeCast=Actor||Director
)