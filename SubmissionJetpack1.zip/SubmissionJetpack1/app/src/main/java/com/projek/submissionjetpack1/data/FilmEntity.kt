package com.projek.submissionjetpack1.data

data class FilmEntity(
    val idFilm: String,
    var title: String,
    var rating: String,
    var releaseDate: String,
    var description: String,
    var imageMovie: String,
    var genres: String,
    var idDirector: String,
    var filmType:String
    //filmType=movie||tvShow
) {
    var idActorDirected: ArrayList<String>? = null
}