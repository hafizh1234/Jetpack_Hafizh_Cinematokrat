package com.projek.submissionjetpack1.ui.caster

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.projek.submissionjetpack1.R
import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.databinding.ActivityCasterBinding
import com.projek.submissionjetpack1.ui.detailFilm.DetailFilmActivities

class CasterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCasterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCasterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[CasterViewModel::class.java]

        var extra = intent.extras
        var actorChosen: Casting
        if (extra != null) {
            var typeCaster = extra.getString(ExtraType)
            var actorId = extra.getString(ExtraCasterId)
            var info = viewModel.getInfo()

            if (info[0] == "" || info[1] == "") {
                if (actorId != null && typeCaster != null) {
                    viewModel.initialize(actorId, typeCaster)
                }
            }
            actorChosen = viewModel.getCaster()
            fillActor(actorChosen)
        }

    }

    private fun fillActor(actor: Casting) {
        with(binding) {
            casterName.text = actor.nameCaster
            dateAndPlaceOfBirth.text = "${actor.placeOfBirth}\n${actor.dateOfBirth}"
            casting.text = actor.typeCast
            if (actor.imageCaster != "") {
                Glide.with(this@CasterActivity)
                    .load(actor.imageCaster)
                    .apply {
                        RequestOptions.placeholderOf(R.drawable.ic_loading)
                            .error(R.drawable.error)
                    }
                    .into(imageView)
            }
            biographyCaster.text = actor.biographyCaster
        }
    }

    companion object {
        var ExtraType = "extra_type"
        var ExtraCasterId = "extra_actor"
    }
}