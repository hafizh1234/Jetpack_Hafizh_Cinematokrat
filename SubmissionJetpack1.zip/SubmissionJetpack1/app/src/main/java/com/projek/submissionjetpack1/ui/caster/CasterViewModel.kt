package com.projek.submissionjetpack1.ui.caster

import androidx.lifecycle.ViewModel
import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.utils.DataDummy

class CasterViewModel : ViewModel() {
    private var actorChosenId:String=""
    private var typeCasterChosen:String=""
    fun initialize(actorId: String, typeCaster: String) {
        this.actorChosenId = actorId
        this.typeCasterChosen = typeCaster
    }

    fun getInfo(): ArrayList<String?> {
        return arrayListOf(actorChosenId, typeCasterChosen)
    }

    fun getActors(): ArrayList<Casting> {
        return DataDummy.getActor()
    }

    fun getDirectors(): ArrayList<Casting> {
        return DataDummy.getDirector()
    }

    fun getCaster(): Casting {
        var info = getInfo()
        var caster = Casting("", "", "", "", "", "", "", "'")
        if (info[1] == "Director") {
            var directors = getDirectors()
            for (director in directors) {
                if (director.idCaster == info[0]) {
                    caster = director
                }
            }
        } else {
            var actors = getActors()
            for (actor in actors) {
                if (actor.idCaster == info[0]) {
                    caster = actor
                }
            }
        }
        return caster
    }
}