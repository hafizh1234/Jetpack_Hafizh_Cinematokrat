package com.projek.submissionjetpack1.ui.detailFilm

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.projek.submissionjetpack1.R
import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.data.FilmEntity
import com.projek.submissionjetpack1.databinding.ActivityDetailFilmActivitiesBinding
import com.projek.submissionjetpack1.databinding.ContentDetailFilmBinding
import com.projek.submissionjetpack1.ui.caster.CasterActivity

class DetailFilmActivities : AppCompatActivity(), ActorCallback {
    companion object {
        var ExtraFilmId = "extra_film"
        var FilmType = "film_type"
    }

    private lateinit var actorDirected: ArrayList<Casting>
    private lateinit var actorAdapter: ActorAdapter
    private lateinit var genreAdapter: GenreAdapter
    private lateinit var bindingContent: ContentDetailFilmBinding
    private var film = FilmEntity("", "", "", "", "", "", "", "", "")
    private lateinit var viewModel: DetailFilmViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivityDetailFilmActivitiesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bindingContent = binding.contentDetail
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        genreAdapter = GenreAdapter()
        actorDirected = arrayListOf()
        actorAdapter = ActorAdapter(this)
        viewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[DetailFilmViewModel::class.java]

        var extras = intent.extras
        if (extras != null) {
            var idFilm: String? = extras.getString(ExtraFilmId)
            var filmType: String? = extras.getString(FilmType)
            var info = viewModel.getCurrentInfo()
            if (info[0] == "" || info[1] == "") {
                if (idFilm != null && filmType != null) {
                    viewModel.initialize(idFilm, filmType)
                }
            }

            if (idFilm != null) {
                film = viewModel.getFilmChosen()

                actorDirected.add(viewModel.getDirectorCredited())

                actorDirected.addAll(viewModel.getActorsDirected())
                actorAdapter.setActor(actorDirected)
                var genres = viewModel.getGenre()
                //var genres = film.genres.split(",")
                genreAdapter.setListGenre(genres)
                populateFilm()
            }
        }
        with(bindingContent) {
            with(rvActor) {
                layoutManager = LinearLayoutManager(this@DetailFilmActivities)
                setHasFixedSize(true)
                adapter = actorAdapter
            }
            with(rvGenre) {
                layoutManager = LinearLayoutManager(this@DetailFilmActivities)
                setHasFixedSize(true)
                adapter = genreAdapter
            }
        }
        //Toast.makeText(this,"${viewModel.getCurrentInfo()}",Toast.LENGTH_LONG).show()
    }

    private fun populateFilm() {
        with(bindingContent) {
            titleFilm.text = film.title
            ratingFilm.text = film.rating
            releaseDate.text = film.releaseDate
            description.text = film.description
            Glide.with(this@DetailFilmActivities)
                .load(film.imageMovie)
                .apply {
                    RequestOptions.placeholderOf(R.drawable.ic_loading)
                        .error(R.drawable.error)
                }
                .into(imageView)
        }
    }

    override fun castingClicked(caster: Casting) {
        var intent = Intent(this, CasterActivity::class.java)
        intent.putExtra(CasterActivity.ExtraType, caster.typeCast)
        intent.putExtra(CasterActivity.ExtraCasterId, caster.idCaster)
        startActivity(intent)
    }
}