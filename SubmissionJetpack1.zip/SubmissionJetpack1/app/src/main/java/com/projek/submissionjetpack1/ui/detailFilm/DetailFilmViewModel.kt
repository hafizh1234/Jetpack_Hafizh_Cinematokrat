package com.projek.submissionjetpack1.ui.detailFilm

import androidx.lifecycle.ViewModel
import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.data.FilmEntity
import com.projek.submissionjetpack1.utils.DataDummy

class DetailFilmViewModel : ViewModel() {
    private var typeFilmChosen: String = ""
    private var idFilm: String = ""

    fun initialize(idFilmPicked: String, typeFilm: String) {
        this.idFilm = idFilmPicked
        this.typeFilmChosen = typeFilm
    }

    fun getDirectors(): List<Casting> {
        return DataDummy.getDirector()
    }

    fun getTvShow(): List<FilmEntity> {
        return DataDummy.getTvShow()
    }

    fun getMovie(): List<FilmEntity> {
        return DataDummy.getMovies()
    }

    fun getCurrentInfo(): ArrayList<String?> {
        return arrayListOf(this.idFilm, this.typeFilmChosen)
    }

    fun getActors(): List<Casting> {
        return DataDummy.getActor()
    }

    fun getFilmChosen(): FilmEntity {
        var filmResult: FilmEntity = FilmEntity("", "", "", "", "", "", "", "", "")
        var info = getCurrentInfo()
        if (info[1] == "Movie") {
            var movies = getMovie()
            for (movie in movies) {
                if (info[0] == movie.idFilm) {
                    filmResult = movie
                    break
                }
            }
        } else {
            var arrayListTvShows = getTvShow()
            for (tvShow in arrayListTvShows) {
                if (info[0] == tvShow.idFilm) {
                    filmResult = tvShow
                    break
                }
            }
        }
        return filmResult
    }

    fun getDirectorCredited(): Casting {
        var directors = getDirectors()
        var directorCharged = Casting("", "", "", "", "", "", "", "")
        var film = getFilmChosen()
        var idDirector = film.idDirector
        for (director in directors) {
            if (idDirector == director.idCaster) {
                directorCharged = director
                break
            }
        }
        return directorCharged
    }

    fun getActorsDirected(): ArrayList<Casting> {
        var actors = getActors()
        var actorsDirected: ArrayList<Casting> = arrayListOf()
        var film = getFilmChosen()
        var idActors: ArrayList<String>? = film.idActorDirected

        for (actor in actors) {
            var actorFound = idActors?.firstOrNull { it == actor.idCaster }
            if (actorFound != null) {
                actorsDirected.add(actor)
            }
        }
        return actorsDirected
    }

    fun getGenre(): List<String> {
        var film = getFilmChosen()
        var genres = film.genres
        var genresResult: List<String> = genres.split(",")
        return genresResult
    }
}