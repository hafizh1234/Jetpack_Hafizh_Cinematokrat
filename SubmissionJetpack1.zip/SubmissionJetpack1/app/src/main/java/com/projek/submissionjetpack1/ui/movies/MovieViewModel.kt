package com.projek.submissionjetpack1.ui.movies

import androidx.lifecycle.ViewModel
import com.projek.submissionjetpack1.data.FilmEntity
import com.projek.submissionjetpack1.utils.DataDummy

class MovieViewModel:ViewModel() {
    fun getMovie(): ArrayList<FilmEntity> {
        return DataDummy.getMovies()
    }
}