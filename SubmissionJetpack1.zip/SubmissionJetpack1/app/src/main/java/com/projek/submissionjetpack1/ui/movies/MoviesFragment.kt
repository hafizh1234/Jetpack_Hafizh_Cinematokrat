package com.projek.submissionjetpack1.ui.movies

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ShareCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.projek.submissionjetpack1.R
import com.projek.submissionjetpack1.data.FilmEntity
import com.projek.submissionjetpack1.databinding.FragmentMoviesBinding
import com.projek.submissionjetpack1.ui.detailFilm.DetailFilmActivities

class MoviesFragment : Fragment(), MovieCallback {
    private var _binding: FragmentMoviesBinding? = null
    private val binding get() = _binding!!
    private lateinit var movieDummy: ArrayList<FilmEntity>
    private lateinit var movieAdapter: MovieAdapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            val viewModel = ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            )[MovieViewModel::class.java]

            movieDummy=viewModel.getMovie()
            movieAdapter = MovieAdapter(this)
            movieAdapter.setListMovie(movieDummy)
            with(binding.rvMovie) {
                layoutManager = LinearLayoutManager(requireActivity())
                setHasFixedSize(true)
                this.adapter = movieAdapter
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMoviesBinding.inflate(inflater)
        return binding.root
    }

    override fun movieShare(filmEntity: FilmEntity) {
        if (activity != null) {
            val mimeType = "text/plain"
            val shareCompat = ShareCompat.IntentBuilder(requireActivity())
            shareCompat.setChooserTitle("Bagikan informasi film")
            shareCompat.setType(mimeType)
            shareCompat.setText(resources.getString(R.string.text_share, filmEntity.title))
            shareCompat.startChooser()
        }
    }

    override fun navigateToDetail(filmEntity: FilmEntity) {
        var intent = Intent(requireActivity(), DetailFilmActivities::class.java)
        intent.putExtra(DetailFilmActivities.ExtraFilmId, filmEntity.idFilm)
        intent.putExtra(DetailFilmActivities.FilmType, filmEntity.filmType)
        startActivity(intent)
    }

}