package com.projek.submissionjetpack1.ui.tvShow

import androidx.lifecycle.ViewModel
import com.projek.submissionjetpack1.data.FilmEntity
import com.projek.submissionjetpack1.utils.DataDummy

class TvShowViewModel:ViewModel() {
    fun getTvShows(): ArrayList<FilmEntity> {
        return DataDummy.getTvShow()
    }
}