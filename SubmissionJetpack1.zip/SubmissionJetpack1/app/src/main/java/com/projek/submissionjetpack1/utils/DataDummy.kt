package com.projek.submissionjetpack1.utils

import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.data.FilmEntity

object DataDummy {
    fun getDirector(): ArrayList<Casting> {
        var directors = ArrayList<Casting>()
        directors.add(
            Casting(
                "D001",
                "Bradley Cooper",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/DPnessSsWqVXRbKm93PtMjB4Us.jpg",
                "Bradley Charles Cooper (born 5 January 1975) is an American actor and filmmaker. He has been nominated for many awards, including eight Academy Awards and a Tony Award, and has won two Grammy Awards and a BAFTA Award. He appeared in Forbes Celebrity 100 on three occasions and Time's list of 100 most influential people in the world in 2015. His films have grossed \$11 billion worldwide and he has placed four times in annual rankings of the highest-paid actors in the world.",
                "Male",
                "05/01/1975",
                "Philadelphia, Pennsylvania, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D002",
                "Dermott Downs",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/vCq8mlxsJOB4rCjanLVoaNtvJVV.jpg",
                "Dermott Downs was born on May 25, 1962. He is a cinematographer and director.",
                "Male",
                "25/03/1962",
                "Los Angeles County, California, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D003",
                "Joe Russo",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/679Os4tbY1YsU01KdLhM1NPXNWu.jpg",
                "Anthony and Joe Russo, known together professionally as the Russo brothers, are Emmy Award-winning American film and television directors. The brothers direct most of their work jointly, and they also occasionally work as producers, actors, and editors. The Russos are from Cleveland, Ohio, and were born a year apart. They are alumni of Case Western Reserve University.",
                "Male",
                "18/07/1971",
                "Cleveland, Ohio, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D004",
                "James Wan",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/5Jtcdbv80koVk0cSZJ0bhqREfaT.jpg",
                "James Wan (born 26 February 1977) is a Malaysia-born Australian film director, screenwriter, producer, and comic book writer. He has primarily worked in the horror genre as the co-creator of the \"Saw\" and \"Insidious\" franchises and the creator of \"The Conjuring\" universe. Wan is also the founder of Atomic Monster Productions, which has produced film and television projects",
                "Male",
                "26/02/1977",
                "Kuching, Sarawak, Malaysia",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D005",
                "Gregg Araki",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zwsni7JgMLOSZRZs5LwpDkortdx.jpg",
                "Gregg Araki (born December 17, 1959) is an American filmmaker. He is noted for his heavy involvement with the New Queer Cinema movement.",
                "Male",
                "17/12/1959",
                "Los Angeles, California, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D006",
                "Liam Neeson",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/bboldwqSC6tdw2iL6631c98l2Mn.jpg",
                "An Irish actor who has been nominated for an Oscar, a BAFTA and three Golden Globe Awards. He has starred in a number of notable roles including Oskar Schindler in Schindler's List, Michael Collins in Michael Collins, Peyton Westlake in Darkman, Jean Valjean in Les Misérables, Qui-Gon Jinn in Star Wars Episode I: The Phantom Menace, Alfred Kinsey in Kinsey, Ras Al Ghul in Batman Begins and the voice of Aslan in The Chronicles of Narnia film series. He has also starred in several other notable films, from major Hollywood studio releases (ie. Excalibur, The Dead Pool, Nell, Rob Roy, The Haunting, Love Actually, Kingdom of Heaven, Taken, Clash of the Titans, The A-Team, Unknown) to smaller arthouse films (ie. Deception, Breakfast on Pluto, Chloe).",
                "Male",
                "07/06/1952",
                "Ballymena, County Antrim, Northern Ireland, UK",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D007",
                "M. Night Shyamalan",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/tOhFWjauKvJgjCVLJFnhbBCZuxZ.jpg",
                "Manoj Nelliyattu \"M. Night\" Shyamalan, born August 6, 1970, is an American filmmaker and actor. He is known for making original films with contemporary supernatural plots and twist endings. He was born in Mahé, India, and raised in Penn Valley, Pennsylvania. The cumulative gross of his films exceeds \$3 billion globally.",
                "Male",
                "06/08/1970",
                "Mahé, Puducherry, India",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D008",
                "Seth MacFarlane",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/8oQJqM51Z0Qtdb7sE6ZfX1peNCB.jpg",
                "Seth Woodbury MacFarlane (born October 26, 1973) is an American animator, writer, comedian, producer, actor, singer, voice actor, and director best known for creating the animated sitcoms Family Guy, American Dad! and The Cleveland Show, for which he also voices many of the shows' various characters.",
                "Male",
                "26/10/1973",
                "Kent, Connecticut, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D009",
                "Matt Groening",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/2HmAw3AN93DGESPi3ibLZgBa8cT.jpg",
                "Matthew Abram \"Matt\" Groening (born February 15, 1954) is an American cartoonist, screenwriter, and producer. He is the creator of the comic strip Life in Hell as well as two successful television series, The Simpsons and Futurama",
                "Male",
                "15/02/1954",
                "Portland, Oregon, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D010",
                "Chris Sanders",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/mrUm1agSL9Kj6dhV6ABVJvrwlie.jpg",
                "Christopher Michael \"Chris\" Sanders (born March 15, 1960) is an American film animator and voice actor best-known for co-directing and co-writing the Disney animated feature Lilo & Stitch, and providing the voice of Experiment 626 from Lilo & Stitch and Leroy from Disney's Leroy & Stitch. After being later dismissed from Walt Disney Animation Studios, Sanders went on to work for DreamWorks Animation, directing the highly acclaimed animated feature film, How to Train Your Dragon. He is currently serving as co-director on the upcoming feature, The Croods",
                "Male",
                "15/03/1960",
                "Colorado, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D011",
                "David Benioff",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/xvNN5huL0X8yJ7h3IZfGG4O2zBD.jpg",
                "David Benioff is an American television producer, writer, and director. Along with his collaborator D. B. Weiss, he is best known as co-creator, showrunner and writer of Game of Thrones, the HBO adaptation of George R. R. Martin's series of books A Song of Ice and Fire.",
                "Male",
                "25/09/1970",
                "New York, New York, USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D012",
                "Frank Darabont",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/nvOqAQhKtXdHtczgqanoCfltsxJ.jpg",
                "Frank Darabont (born January 28, 1959) is a Hungarian-American film director, screenwriter and producer who has been nominated for three Academy Awards and a Golden Globe. He was born in France by Hungarian parents who fled Budapest during the 1956 uprising, but the family moved to Los Angeles while he was still an infant",
                "Male",
                "28/01/1959",
                "Montbéliard, Doubs, France",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D013",
                "Alexey Sidorov",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/fPMq8wzldlSNgFObz3DGJxIpG3r.jpg",
                "We don't have a biography for Alexey Sidorov.",
                "Male",
                "22-08-1968",
                "Severodvinsk, Russia",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D014",
                "Rodney Rothman",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/3GlFmeP4me6uxZGVsmnC0d4A5BV.jpg",
                "We don't have a biography for Rodney Rothman.",
                "Male",
                "-",
                "United States",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D015",
                "Steven Caple Jr.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/aU8p958QyhfV2jurc3L5pn7sN6L.jpg",
                "We don't have a biography for Steven Caple Jr..",
                "Male",
                "01/01/1988",
                "Cleveland,Ohio,USA",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D016",
                "Ridley Scott",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zABJmN9opmqD4orWl3KSdCaSo7Q.jpg",
                "Ridley Scott was born on 30th November, 1937, in South Shields, Tyne and Wear, England, the son of Elizabeth and Colonel Francis Percy Scott. He was raised in an Army family, meaning that for most of his early life, his father — an officer in the Royal Engineers — was absent. Ridley's older brother, Frank, joined the Merchant Navy when he was still young and the pair had little contact. During this time the family moved around, living in (among other areas) Cumbria, Wales and Germany. He has a younger brother, Tony, also a film director. After the Second World War, the Scott family moved back to their native north-east England, eventually settling in Teesside (whose industrial landscape would later inspire similar scenes in Blade Runner). He enjoyed watching films, and his favourites include Lawrence of Arabia, Citizen Kane and Seven Samurai. Scott studied in Teesside from 1954 to 1958, at Grangefield Grammar School and later in West Hartlepool College of Art, graduating with a Diploma in Design. He progressed to an M.A. in graphic design at the Royal College of Art from 1960 to 1962",
                "Male",
                "30/11/1937",
                "South Shields, County Durham, England, UK",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D017",
                "Greg Berlanti",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/1T24SiIIDMa9gAmq7QaYwZywq4y.jpg",
                "Greg Berlanti (born May 24, 1972) is an American television writer and producer.",
                "Male",
                "24/06/1972",
                "Rye, New York",
                "Director"

            )
        )
        directors.add(
            Casting(
                "D018",
                "Tatsuma Minamikawa",
                "",
                "We don't have a biography for Tatsuma Minamikawa.",
                "Male",
                "-",
                "-",
                "Director"
            )
        )
        directors.add(
            Casting(
                "D019",
                "Donald P. Bellisario",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/8xjZRZvWfn0aaZVHlYxRUtlqJIR.jpg",
                "Donald Paul Bellisario (born August 8, 1935) is an American television producer and screenwriter who created and sometimes wrote episodes for the TV series Magnum, P.I., Airwolf, Quantum Leap, JAG, and NCIS. He has often included military veterans as characters.",
                "Male",
                "08/08/1935",
                "Cokeburgh, Pennsylvanie, USA",
                "Director"
            )
        )
        return directors
    }

    fun getTvShow(): ArrayList<FilmEntity> {
        var tvShow = ArrayList<FilmEntity>()
        tvShow.add(
            FilmEntity(
                "TS001",
                "The Flash",
                "3.9",
                "09/10/2018",
                "After a particle accelerator causes a freak storm, CSI Investigator Barry Allen is struck by lightning and falls into a coma. Months later he awakens with the power of super speed, granting him the ability to move through Central City like an unseen guardian angel. Though initially excited by his newfound powers, Barry is shocked to discover he is not the only \"meta-human\" who was created in the wake of the accelerator explosion -- and not everyone is using their new powers for good. Barry partners with S.T.A.R. Labs and dedicates his life to protect the innocent. For now, only a few close friends and associates know that Barry is literally the fastest man alive, but it won't be long before the world learns what Barry Allen has become...The Flash.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/fki3kBlwJzFp8QohL43g9ReV455.jpg",
                "Drama,Sci-Fi,Fantasy",
                "D002",
                "TvShow"
            )
        )
        tvShow[0].idActorDirected = arrayListOf()
        tvShow[0].idActorDirected?.add("A002")
        tvShow[0].idActorDirected?.add("A003")
        tvShow.add(
            FilmEntity(
                "TS002",
                "The Arrow",
                "3.35",
                "12/10/2017",
                "Spoiled billionaire playboy Oliver Queen is missing and presumed dead when his yacht is lost at sea. He returns five years later a changed man, determined to clean up the city as a hooded vigilante armed with a bow.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/gKG5QGz5Ngf8fgWpBsWtlg5L2SF.jpg",
                "Crime,Drama,Mystery,Action,Adventure",
                "D002",
                "TvShow"
            )
        )
        tvShow[1].idActorDirected = arrayListOf()
        tvShow[1].idActorDirected?.add("A003")
        tvShow[1].idActorDirected?.add("A002")
        tvShow.add(
            FilmEntity(
                "TS003",
                "Riverdale",
                "4.3",
                "09/10/2019",
                "Set in the present, the series offers a bold, subversive take on Archie, Betty, Veronica and their friends, exploring the surreality of small-town life, the darkness and weirdness bubbling beneath Riverdale’s wholesome facade.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/wRbjVBdDo5qHAEOVYoMWpM58FSA.jpg",
                "Mystery,Drama,Crime",
                "D005",
                "TvShow"
            )
        )
        tvShow[2].idActorDirected = arrayListOf()
        tvShow[2].idActorDirected?.add("A004")
        tvShow.add(
            FilmEntity(
                "TS004",
                "Family Guy",
                "3.55",
                "31/01/1999",
                "Sick, twisted, politically incorrect and Freakin' Sweet animated series featuring the adventures of the dysfunctional Griffin family. Bumbling Peter and long-suffering Lois have three kids. Stewie (a brilliant but sadistic baby bent on killing his mother and taking over the world), Meg (the oldest, and is the most unpopular girl in town) and Chris (the middle kid, he's not very bright but has a passion for movies). The final member of the family is Brian - a talking dog and much more than a pet, he keeps Stewie in check whilst sipping Martinis and sorting through his own life issues.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/eWWCRjBfLyePh2tfZdvNcIvKSJe.jpg",
                "Animation,Comedy",
                "D008",
                "TvShow"
            )
        )
        tvShow[3].idActorDirected = arrayListOf()
        tvShow[3].idActorDirected?.add("A008")
        tvShow[3].idActorDirected?.add("A019")
        tvShow.add(
            FilmEntity(
                "TS005",
                "The Simpsons",
                "3.95",
                "19/04/1987",
                "Set in Springfield, the average American town, the show focuses on the antics and everyday adventures of the Simpson family; Homer, Marge, Bart, Lisa and Maggie, as well as a virtual cast of thousands. Since the beginning, the series has been a pop culture icon, attracting hundreds of celebrities to guest star. The show has also made name for itself in its fearless satirical take on politics, media and American life in general",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/tubgEpjTUA7t0kejVMBsNBZDarZ.jpg",
                "Family,Animation,Comedy",
                "D009",
                "TvShow"
            )
        )
        tvShow[4].idActorDirected = arrayListOf()
        tvShow[4].idActorDirected?.add("A009")

        tvShow.add(
            FilmEntity(
                "TS006",
                "Game Of Thrones",
                "4.2",
                "05/12/2010",
                "Seven noble families fight for control of the mythical land of Westeros. Friction between the houses leads to full-scale war. All while a very ancient evil awakens in the farthest north. Amidst the war, a neglected military order of misfits, the Night's Watch, is all that stands between the realms of men and icy horrors beyond",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/gwPSoYUHAKmdyVywgLpKKA4BjRr.jpg",
                "Sci-Fi,Fantasy,Drama,Action,Adventure",
                "D011",
                "TvShow"
            )
        )
        tvShow[5].idActorDirected = arrayListOf()
        tvShow[5].idActorDirected?.add("A006")
        tvShow.add(
            FilmEntity(
                "TS007",
                "The Walking Dead",
                "4.05",
                "11/10/2010",
                "Sheriff's deputy Rick Grimes awakens from a coma to find a post-apocalyptic world dominated by flesh-eating zombies. He sets out to find his family and encounters many other survivors along the way",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/w21lgYIi9GeUH5dO8l3B9ARZbCB.jpg",
                "Action,Adventure,Drama,Sci-Fi,Fantasy",
                "D012",
                "TvShow"

            )
        )
        tvShow[6].idActorDirected = arrayListOf()
        tvShow[6].idActorDirected?.add("A011")
        tvShow.add(
            FilmEntity(
                "TS008",
                "Supergirl",
                "3.65",
                "09/12/2019",
                "Twenty-four-year-old Kara Zor-El, who was taken in by the Danvers family when she was 13 after being sent away from Krypton, must learn to embrace her powers after previously hiding them. The Danvers teach her to be careful with her powers, until she has to reveal them during an unexpected disaster, setting her on her journey of heroism",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zsaiq8ZclPuneuN7loLEbsh1ANJ.jpg",
                "Drama,Sci-Fi,Fantasy,Action,Adventure",
                "D017",
                "TvShow"
            )
        )
        tvShow[7].idActorDirected = arrayListOf()
        tvShow[7].idActorDirected?.add("A017")
        tvShow[7].idActorDirected?.add("A002")
        tvShow[7].idActorDirected?.add("A003")
        tvShow.add(
            FilmEntity(
                "TS009",
                "Fairy Tail: Dragon Cry",
                "3.25",
                "05/06/2017",
                "Natsu Dragneel and his friends travel to the island Kingdom of Stella, where they will reveal dark secrets, fight the new enemies and once again save the world from destruction.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/4CtvjdvuRj3iPlvtpvFomhTxjXR.jpg",
                "Action,Adventure,Comedy,Fantasy,Animation",
                "D018",
                "TvShow"
            )
        )
        tvShow[8].idActorDirected= arrayListOf()
        tvShow[8].idActorDirected?.add("A018")
        tvShow.add(
            FilmEntity(
                "TS010",
                "NCIS",
                "3.75",
                "22/04/2003",
                "From murder and espionage to terrorism and stolen submarines, a team of special agents investigates any crime that has a shred of evidence connected to Navy and Marine Corps personnel, regardless of rank or position",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/lSTchtc26YNdOjdKvZtLs22SokL.jpg",
                "Crime,Action,Adventure,Drama",
                "D019",
                "TvShow"
            )
        )
        tvShow[9].idActorDirected= arrayListOf()
        tvShow[9].idActorDirected?.add("A019")

        return tvShow
    }

    fun getActor(): ArrayList<Casting> {
        var actors = ArrayList<Casting>()
        actors.add(
            Casting(
                "A001",
                "Lady Gaga",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/unNh9e9CEEx2VYZttKuAh1XVMWW.jpg",
                "Stefani Joanne Angelina Germanotta (born March 28, 1986), better known by her stage name Lady Gaga, is an American singer, songwriter, and actress. After performing in the rock music scene of New York City's Lower East Side in 2003 and later enrolling at New York University's Tisch School of the Arts, she soon signed with Streamline Records, an imprint of Interscope Records. During her early time at Interscope, she worked as a songwriter for fellow label artists and captured the attention of recording artist Akon, who recognized her vocal abilities, and signed her to his own label, Kon Live Distribution.",
                "Female",
                "28/03/1986",
                "New York City, New York, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A002",
                "Grant Gustin",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/kEGU1gGySIe63lyL7AnwXEw4rQn.jpg",
                "Thomas Grant Gustin (born January 14, 1990) is an American actor and singer. He is best known for his roles as Barry Allen / The Flash on the CW series The Flash as part of the Arrowverse television franchise, and for his role as Sebastian Smythe on the Fox series Glee.",
                "Male",
                "14/01/1990",
                "Norfolk, Virginia, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A003",
                "Stephen Amell",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/gN8cpnUaPIzWhVufahmzV0dwOgp.jpg",
                "Stephen Amell (born May 8, 1981) is a Canadian actor known for his role on the television series Rent-a-Goalie, as well as his work co-starring opposite Shirley MacLaine and Mischa Barton in the feature length motion picture Closing the Ring. He is best known for his role as Oliver Queen in The CW's Arrow.",
                "Male",
                "1981/05/08",
                "Toronto, Ontario, Canada",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A004",
                "K.J. Apa",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/idpwm8ZdFnndjeQ3mKleF20hvRo.jpg",
                "He is an actor, known for A Dog's Purpose (2017), Riverdale (2017) and Shortland Street (1992).",
                "Male",
                "17/06/1997",
                "Auckland, NewZealand",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A005",
                "Robert Downey Jr.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/5qHNjhtjMD4YWH3UP0rm4tKwxCL.jpg",
                "Robert John Downey Jr. (born April 4, 1965) is an American actor and producer. Downey made his screen debut in 1970, at the age of five, when he appeared in his father's film Pound, and has worked consistently in film and television ever since. He received two Academy Award nominations for his roles in films Chaplin (1992) and Tropic Thunder (2008).",
                "Male",
                "04/04/1965",
                "Manhattan, New York, USA",
                "Actor"
            )
        )

        actors.add(
            Casting(
                "A006",
                "Jason Momoa",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/6dEFBpZH8C8OijsynkSajQT99Pb.jpg",
                "Joseph Jason Namakaeha Momoa (born August 1, 1979) is a Kānaka-American actor, model, and producer. He is known for his television roles as Ronon Dex on the military science fiction television series Stargate Atlantis (2004–2009), Khal Drogo in the HBO fantasy television series Game of Thrones (2011–2012), and Declan Harp in the Netflix series Frontier (2016–present). He is also known in the DC Extended Universe as the character Aquaman.",
                "Male",
                "01/08/1979",
                "Honolulu, Hawaii, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A007",
                "Laura Dern",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/gB9PnGEvxKg33OSlcqptQwTBwPE.jpg",
                "An American actress, film director and producer. Dern has acted in such films as Smooth Talk (1985), Blue Velvet (1986), Fat Man and Little Boy (1988), Wild at Heart (1990), Jurassic Park (1993) and October Sky (1999). She has won awards for her performance in the 1991 film Rambling Rose, for which she received an Academy Award nomination for Best Actress in a Leading Role. She was awarded a Golden Globe Award for Best Supporting Actress – Series, Miniseries or Television Film for her portrayal of Florida Secretary of State Katherine Harris in the film Recount (2008).",
                "Female",
                "10/02/1967",
                "Los Angeles, California, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A008",
                "Alex Borstein",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/evbCnRe5Yfuy0B41PONLTIcvbem.jpg",
                "Alexandrea \"Alex\" Borstein (born February 15, 1973) is an American actress, singer, voice actress, writer and comedian. She is best known for her long-running role as Lois Griffin on the animated television series Family Guy, and as a cast member on the sketch comedy series MADtv.",
                "Female",
                "15/02/1971",
                "Highland, Illinois, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A009",
                "Dan Castellaneta",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/AmeqWhP4A46AWkM4kVphg6jOTQX.jpg",
                "Dan Castellaneta (born October 29, 1957) is an American film, theatre and television actor, comedian, voice artist, singer and television writer. Noted for his long-running role as Homer Simpson on The Simpsons, he voices many other regular characters on it",
                "Male",
                "29/10/1957",
                "Chicago, Illinois, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A010",
                "James McAvoy",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/vB6qYlFXgONGVwwxWXE4gf0F8SQ.jpg",
                "A Scottish stage and screen actor. His best-known work includes the films The Last King of Scotland and Atonement, both of which earned him BAFTA Award nominations, and the TV series Shameless. McAvoy has won the BAFTA Rising Star Award and a BAFTA Scotland award. He has also been nominated for an ALFS Award, a European Film Award, and a Golden Globe award",
                "Male",
                "21/04/1979",
                "Glasgow, Scotland, UK",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A011",
                "Norman Reedus",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ozHPdO5jAt7ozzdZUgyRAMNPSDW.jpg",
                "Norman Mark Reedus (born January 6, 1969) is an American actor, voice actor, television host, and model. Reedus is known for starring in the popular AMC horror drama series The Walking Dead as Daryl Dixon, in the film The Boondock Saints (1999) and its sequel The Boondock Saints II: All Saints Day (2009) as Murphy MacManus, as Scud in Marvel's Blade II (2002), Marco in Deuces Wild (2002) and for his AMC TV show Ride with Norman Reedus. He has acted in numerous films and television series, and modeled for various fashion designers (most recognizably Prada in the 1990s). Reedus also provided motion capture and voice acting for the lead character Sam Porter in the video game Death Stranding (2019).",
                "Male",
                "06/01/1969",
                "Hollywood, Florida, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A012",
                "Jay Baruchel",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/aDfqAMsPzIZvvj1ymivsKjRAfyv.jpg",
                "Jay Baruchel (born April 9, 1982) is a Canadian actor. He has had a successful career in comedy films, and has appeared in such box office successes as Million Dollar Baby, Knocked Up, Tropic Thunder, and How to Train Your Dragon, as well as the films She's Out of My League, The Trotsky, and The Sorcerer's Apprentice.",
                "Male",
                "09/04/1982",
                "Ottawa, Ontario, Canada",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A013",
                "Alexander Petrov",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/v3pbf4pHtEvRxBnU56D6uGm5RPm.jpg",
                "We don't have a biography for Alexander Petrov.",
                "Male",
                "25/01/1989",
                "Pereslavl-Zalessky, Yaroslavl region, Russia",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A014",
                "Shameik Moore",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/uJNaSTsfBOvtFWsPP23zNthknsB.jpg",
                "Shameik Alti Moore (born May 4, 1995) is an American actor, singer, and rapper.\n" +
                        "Moore was born in Atlanta, Georgia. He attended Druid Hills High School. His family originates from Jamaica.\n" +
                        "Moore started off with bit roles from shows such as Tyler Perry's House of Payne, Reed Between the Lines, and Joyful Noise. In 2013, he had his first main television role on the sketch-comedy series Incredible Crew, which aired on Cartoon Network before being cancelled after one season. He then gained recognition with his portrayal of Malcolm in the 2015 film Dope, which premiered at the 2015 Sundance Film Festival. Indiewire included Moore on its list of \"The 12 Major Breakouts of the 2015 Sundance Film Festival\" for his performance in the movie. He is also one of the five male leads in the Netflix series The Get Down, which premiered in 2016 and was cancelled in 2017 after one half-season. Moore voiced Miles Morales in the animated film Spider-Man: Into the Spider-Verse from Sony Pictures Animation, which was released in December 2018.",
                "Male",
                "04/05/1995",
                "Atlanta, Georgia, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A015",
                "Michael B. Jordan",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/kfcn0yyEdN2aJfVaxW0NIoKVF4J.jpg",
                "Michael Bakari Jordan (/bɑːˈkɑːriː/; born February 9, 1987) is an American actor and producer. He is known for his film roles as shooting victim Oscar Grant in the drama Fruitvale Station (2013), boxer Donnie Creed in Creed (2015), and Erik Killmonger in Black Panther (2018), all three of which were directed by Ryan Coogler. Jordan reprised the role of Creed in Creed II (2018), and is set to star, and make his directorial debut, in Creed III (2022).",
                "Male",
                "09/02/1987",
                "Santa Ana, California, USA",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A016",
                "Russell Crowe",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/uxiXuVH4vNWrKlJMVVPG1sxAJFe.jpg",
                "Russell Ira Crowe (born 7 April 1964) is a New Zealand-born Australian actor and musician. His acting career began in the late 1980s with roles in Australian television series including Police Rescue and Neighbours. In the early 1990s, Crowe's local prominence peaked when he won the Australian Film Industry Award for Best Actor for his portrayal of an inner-city skinhead in the Geoffrey Wright film, Romper Stomper. In the late 1990s, Crowe transferred his acting ambitions to the USA with his breakout role in L.A. Confidential (1997). Crowe won the Academy Award for Best Actor for Gladiator in 2001 and has received three Academy Award nominations for Best Actor in a Leading Role: The Insider (1999), Gladiator (2000) and A Beautiful Mind (2001). He is also co-owner of National Rugby League team the South Sydney Rabbitohs.",
                "Male",
                "07/04/1964",
                "Wellington, New Zealand",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A017",
                "David Harewood",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/8scO8ISd5UH6MNMr9kyb4H6aAWD.jpg",
                "David Harewood is an English actor, known for playing David Estes in Homeland and Hank Henshaw in Supergirl.",
                "Male",
                "08/12/1965",
                "Small Heath, Birmingham, England, UK",
                "Actor"
            )
        )

        actors.add(
            Casting(
                "A018",
                "Makoto Furukawa",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ayE3vqqNYt4wBQIvoEVka4oFDw6.jpg",
                "We don't have a biography for Makoto Furukawa.",
                "Male",
                "29/09/1989",
                "Kumamoto Prefecture, Japan",
                "Actor"
            )
        )
        actors.add(
            Casting(
                "A019",
                "Mark Harmon",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/lMqKPig7zBoGfou7wWf88sZEGHo.jpg",
                "Mark Harmon (born September 2, 1951) is an American actor who has been starring in U.S. television programs and films since the mid-1970s, after a career as a collegiate football player with the UCLA Bruins. Since 2003, Harmon has starred as Leroy Jethro Gibbs in the CBS series NCIS.",
                "Male",
                "02/09/1951",
                "Burbank, California, USA",
                "Actor"
            )
        )
        return actors
    }

    fun getMovies(): ArrayList<FilmEntity> {
        var movies = ArrayList<FilmEntity>()
        movies.add(
            FilmEntity(
                "MV001",
                "A Star Is Born",
                "3.75",
                "10/05/2018",
                "Seasoned musician Jackson Maine discovers — and falls in love with — struggling artist Ally. She has just about given up on her dream to make it big as a singer — until Jack coaxes her into the spotlight. But even as Ally's career takes off, the personal side of their relationship is breaking down, as Jack fights an ongoing battle with his own internal demons.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/wrFpXMNBRj2PBiN4Z5kix51XaIZ.jpg",
                "Drama,Romance,Music",
                "D001",
                "Movie"
            )
        )
        movies[0].idActorDirected = arrayListOf()
        movies[0].idActorDirected?.add("A001")
        movies.add(
            FilmEntity(
                "MV002",
                "Avengers: Infinity War",
                "4.15",
                "27/04/2018",
                "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg",
                "Adventure,Action,Science Fiction",
                "D003",
                "Movie"
            )
        )
        movies[1].idActorDirected = arrayListOf()
        movies[1].idActorDirected?.add("A005")

        movies.add(
            FilmEntity(
                "MV003",
                "Aquaman",
                "3.45",
                "21/12/2018",
                "Once home to the most advanced civilization on Earth, Atlantis is now an underwater kingdom ruled by the power-hungry King Orm. With a vast army at his disposal, Orm plans to conquer the remaining oceanic people and then the surface world. Standing in his way is Arthur Curry, Orm's half-human, half-Atlantean brother and true heir to the throne.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/xLPffWMhMj1l50ND3KchMjYoKmE.jpg",
                "Action,Adventure,Fantasy",
                "D004",
                "Movie"
            )
        )
        movies[2].idActorDirected = arrayListOf()
        movies[2].idActorDirected?.add("A006")

        movies.add(
            FilmEntity(
                "MV004",
                "Cold Pursuit",
                "2.85",
                "02/08/2019",
                "The quiet family life of Nels Coxman, a snowplow driver, is upended after his son's murder. Nels begins a vengeful hunt for Viking, the drug lord he holds responsible for the killing, eliminating Viking's associates one by one. As Nels draws closer to Viking, his actions bring even more unexpected and violent consequences, as he proves that revenge is all in the execution.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/hXgmWPd1SuujRZ4QnKLzrj79PAw.jpg",
                "Action,Crime,Thriller",
                "D006",
                "Movie"
            )
        )
        movies[3].idActorDirected = arrayListOf()
        movies[3].idActorDirected?.add("A007")

        movies.add(
            FilmEntity(
                "MV005",
                "Glass",
                "3.35",
                "18/01/2019",
                "In a series of escalating encounters, former security guard David Dunn uses his supernatural abilities to track Kevin Wendell Crumb, a disturbed man who has twenty-four personalities. Meanwhile, the shadowy presence of Elijah Price emerges as an orchestrator who holds secrets critical to both men.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/svIDTNUoajS8dLEo7EosxvyAsgJ.jpg",
                "Thriller,Drama,Science Fiction",
                "D007",
                "Movie"
            )
        )
        movies[4].idActorDirected = arrayListOf()
        movies[4].idActorDirected?.add("A010")

        movies.add(
            FilmEntity(
                "MV006",
                "How to Train Your Dragon",
                "3.9",
                "26/03/2010",
                "As the son of a Viking leader on the cusp of manhood, shy Hiccup Horrendous Haddock III faces a rite of passage: he must kill a dragon to prove his warrior mettle. But after downing a feared dragon, he realizes that he no longer wants to destroy it, and instead befriends the beast – which he names Toothless – much to the chagrin of his warrior father",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/q9JwFktEfzdXlE7gFjKSTOD3jpK.jpg",
                "Fantasy,Adventure,Animation,Family",
                "D010",
                "Movie"
            )
        )
        movies[5].idActorDirected = arrayListOf()
        movies[5].idActorDirected?.add("A012")

        movies.add(
            FilmEntity(
                "MV007",
                "T-34",
                "3.5",
                "01/01/2019",
                "In 1944, a courageous group of Russian soldiers managed to escape from German captivity in a half-destroyed legendary T-34 tank. Those were the times of unforgettable bravery, fierce fighting, unbreakable love, and legendary miracles.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/jqBIHiSglRfNxjh1zodHLa9E7zW.jpg",
                "War,Action,Drama,History",
                "D013",
                "Movie"
            )
        )
        movies[6].idActorDirected = arrayListOf()
        movies[6].idActorDirected?.add("A013")
        movies.add(
            FilmEntity(
                "MV008",
                "Spider-Man: Into the Spider-Verse",
                "4.2",
                "14/12/2018",
                "Miles Morales is juggling his life between being a high school student and being a spider-man. When Wilson \"Kingpin\" Fisk uses a super collider, others from across the Spider-Verse are transported to this dimension",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/iiZZdoQBEYBv6id8su7ImL0oCbD.jpg",
                "Action,Adventure,Animation,Science Fiction,Comedy",
                "D014",
                "Movie"
            )
        )
        movies[7].idActorDirected = arrayListOf()
        movies[7].idActorDirected?.add("A014")
        movies.add(
            FilmEntity(
                "MV009",
                "Creed II",
                "3.45",
                "21/11/2018",
                "Between personal obligations and training for his next big fight against an opponent with ties to his family's past, Adonis Creed is up against the challenge of his life.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/v3QyboWRoA4O9RbcsqH8tJMe8EB.jpg",
                "Drama",
                "D015",
                "Movie"
            )
        )
        movies[8].idActorDirected = arrayListOf()
        movies[8].idActorDirected?.add("A015")
        movies.add(
            FilmEntity(
                "MV010",
                "Robin Hood",
                "3.2",
                "14/05/2010",
                "When soldier Robin happens upon the dying Robert of Loxley, he promises to return the man's sword to his family in Nottingham. There, he assumes Robert's identity; romances his widow, Marion; and draws the ire of the town's sheriff and King John's henchman, Godfrey.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/9NS5QGOfck24yL3bZqWeW06PgPC.jpg",
                "Adventure",
                "D016",
                "Movie"
            )
        )
        movies[9].idActorDirected = arrayListOf()
        movies[9].idActorDirected?.add("A016")
        return movies
    }
}