package com.projek.submissionjetpack1.ui.caster

import com.projek.submissionjetpack1.utils.DataDummy
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class CasterViewModelTest {
    private var actor = DataDummy.getActor()[0]
    private var director = DataDummy.getDirector()[0]
    private lateinit var viewModel: CasterViewModel

    @Before
    fun set() {
        viewModel = CasterViewModel()
    }

    @Test
    fun testGetActor() {
        viewModel.initialize(actor.idCaster, actor.typeCast)
        val actorChose = viewModel.getCaster()
        assertNotNull(actor)
        assertEquals(actor.idCaster, actorChose.idCaster)
        assertEquals(actor.nameCaster, actorChose.nameCaster)
        assertEquals(actor.dateOfBirth, actorChose.dateOfBirth)
        assertEquals(actor.placeOfBirth, actorChose.placeOfBirth)
        assertEquals(actor.biographyCaster, actorChose.biographyCaster)
    }

    @Test
    fun testGetDirector() {
        viewModel.initialize(director.idCaster, director.typeCast)
        val directorChose = viewModel.getCaster()
        assertNotNull(directorChose)
        assertEquals(director.idCaster, directorChose.idCaster)
        assertEquals(director.nameCaster, directorChose.nameCaster)
        assertEquals(director.dateOfBirth, directorChose.dateOfBirth)
        assertEquals(director.placeOfBirth, directorChose.placeOfBirth)
        assertEquals(director.biographyCaster, directorChose.biographyCaster)
    }
}