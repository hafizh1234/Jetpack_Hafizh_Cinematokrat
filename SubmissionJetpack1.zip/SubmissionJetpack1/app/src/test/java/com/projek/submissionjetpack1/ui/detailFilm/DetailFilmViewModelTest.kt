package com.projek.submissionjetpack1.ui.detailFilm

import com.projek.submissionjetpack1.data.Casting
import com.projek.submissionjetpack1.utils.DataDummy
import org.junit.Assert
import org.junit.Before
import org.junit.Test

class DetailFilmViewModelTest {

    private lateinit var viewModel: DetailFilmViewModel
    private var movieChosen = DataDummy.getMovies()[0]
    private var tvShowChosen = DataDummy.getTvShow()[0]
    private var idActorMovie: ArrayList<String>? = movieChosen.idActorDirected
    private var idActorTvShowChosen: ArrayList<String>? = tvShowChosen.idActorDirected
    private lateinit var actorMovie: ArrayList<Casting>
    private lateinit var actorTvShow: ArrayList<Casting>
    private var idDirectorMovie: String = movieChosen.idDirector
    private var idDirectorTvShow: String = tvShowChosen.idDirector
    private lateinit var directorMovie: Casting
    private lateinit var directorTvShow: Casting
    private var idMovie = movieChosen.idFilm
    private var idTvShow = tvShowChosen.idFilm
    private var genreMovie = movieChosen.genres
    private var genreTvShow = tvShowChosen.genres

    @Before
    fun set() {
        viewModel = DetailFilmViewModel()

        actorMovie = arrayListOf()
        actorTvShow = arrayListOf()

        val directors = DataDummy.getDirector()
        val actors = DataDummy.getActor()
        for (director in directors) {
            if (director.idCaster == idDirectorMovie) {
                directorMovie = director
            } else if (director.idCaster == idDirectorTvShow) {
                directorTvShow = director
            }
        }
        for (actor in actors) {
            var actorMovieMatch = idActorMovie?.firstOrNull { it == actor.idCaster }
            var actorTvShowMatch = idActorTvShowChosen?.firstOrNull { it == actor.idCaster }
            if (actorMovieMatch != null) {
                actorMovie.add(actor)
            } else if (actorTvShowMatch != null) {
                actorTvShow.add(actor)
            }
        }
    }

    @Test
    fun testGetDirectors() {
        val directorsEntities = viewModel.getDirectors()
        Assert.assertNotNull(directorsEntities)
        Assert.assertEquals(19, directorsEntities.size)
    }

    @Test
    fun testGetActors() {
        val actorEntities = viewModel.getActors()
        Assert.assertNotNull(actorEntities)
        Assert.assertEquals(19, actorEntities.size)
    }

    @Test
    fun testGetMovieChosen() {
        viewModel.initialize(idMovie,"Movie")
        val movie = viewModel.getFilmChosen()
        Assert.assertNotNull(movie)
        Assert.assertEquals(movie.idFilm, idMovie)
        Assert.assertEquals(movie.title, movieChosen.title)
        Assert.assertEquals(movie.releaseDate, movieChosen.releaseDate)
        Assert.assertEquals(movie.rating, movieChosen.rating)
        Assert.assertEquals(movie.genres, movieChosen.genres)
        Assert.assertEquals(movie.idDirector, movieChosen.idDirector)
        Assert.assertEquals(movie.description, movieChosen.description)
    }

    @Test
    fun testGetMovieDirectorCredited() {
        viewModel.initialize(idMovie,"Movie")
        val director = viewModel.getDirectorCredited()
        Assert.assertNotNull(director)
        Assert.assertEquals(director.idCaster, idDirectorMovie)
        Assert.assertEquals(director.nameCaster, directorMovie.nameCaster)
        Assert.assertEquals(director.placeOfBirth, directorMovie.placeOfBirth)
        Assert.assertEquals(director.biographyCaster, directorMovie.biographyCaster)
        Assert.assertEquals(director.imageCaster, directorMovie.imageCaster)
        Assert.assertEquals(director.dateOfBirth, directorMovie.dateOfBirth)
    }

    @Test
    fun testGetMovieActorsDirected() {
        viewModel.initialize(idMovie,"Movie")
        var listActor=viewModel.getActorsDirected()
        for(i in 0 until listActor.size) {
            Assert.assertEquals(actorMovie[i].idCaster, listActor[i].idCaster)
        }
    }

    @Test
    fun testGetMovieGenre() {
        viewModel.initialize(idMovie,"Movie")
        var listGenre=genreMovie.split(",")
        Assert.assertEquals(listGenre,viewModel.getGenre())
    }


    @Test
    fun testGetTvShowChosen() {
        viewModel.initialize(idTvShow,"TvShow")
        val tvShow = viewModel.getFilmChosen()
        Assert.assertNotNull(tvShow)
        Assert.assertEquals(tvShow.idFilm, idTvShow)
        Assert.assertEquals(tvShow.title, tvShowChosen.title)
        Assert.assertEquals(tvShow.releaseDate, tvShowChosen.releaseDate)
        Assert.assertEquals(tvShow.rating, tvShowChosen.rating)
        Assert.assertEquals(tvShow.genres, tvShowChosen.genres)
        Assert.assertEquals(tvShow.idDirector, tvShowChosen.idDirector)
        Assert.assertEquals(tvShow.description, tvShowChosen.description)
    }

    @Test
    fun testGetDirectorTvShowCredited() {
        viewModel.initialize(idTvShow,"TvShow")
        val director = viewModel.getDirectorCredited()
        Assert.assertNotNull(director)
        Assert.assertEquals(director.idCaster, idDirectorTvShow)
        Assert.assertEquals(director.nameCaster, directorTvShow.nameCaster)
        Assert.assertEquals(director.placeOfBirth, directorTvShow.placeOfBirth)
        Assert.assertEquals(director.biographyCaster, directorTvShow.biographyCaster)
        Assert.assertEquals(director.imageCaster, directorTvShow.imageCaster)
        Assert.assertEquals(director.dateOfBirth, directorTvShow.dateOfBirth)
    }

    @Test
    fun testGetTvShowActorsDirected() {
        viewModel.initialize(idTvShow,"TvShow")
        var actors=viewModel.getActorsDirected()
        for(i in 0 until actors.size){
            Assert.assertEquals(actorTvShow[i].idCaster,actors[i].idCaster)
        }
    }

    @Test
    fun testGetTvShowGenre() {
        viewModel.initialize(idTvShow,"TvShow")
        var listOfGenre=genreTvShow.split(",")
        Assert.assertEquals(listOfGenre,viewModel.getGenre())
    }

}