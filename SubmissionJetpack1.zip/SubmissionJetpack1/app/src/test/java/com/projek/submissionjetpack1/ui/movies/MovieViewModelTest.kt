package com.projek.submissionjetpack1.ui.movies

import org.junit.Assert
import org.junit.Before
import org.junit.Test

class MovieViewModelTest {
    private lateinit var viewModel:MovieViewModel

    @Before
    fun setAll(){
        viewModel= MovieViewModel()
    }

    @Test
    fun testGetMovie() {
        val movieEntities=viewModel.getMovie()
        Assert.assertNotNull(movieEntities)
        Assert.assertEquals(10,movieEntities.size)
    }
}