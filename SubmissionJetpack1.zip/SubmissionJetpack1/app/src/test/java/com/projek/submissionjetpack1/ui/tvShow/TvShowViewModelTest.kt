package com.projek.submissionjetpack1.ui.tvShow

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class TvShowViewModelTest {

    private lateinit var viewModel:TvShowViewModel
    @Before
    fun set(){
        viewModel= TvShowViewModel()
    }

    @Test
    fun testGetTvShows() {
        val tvShowEntities=viewModel.getTvShows()
        assertNotNull(tvShowEntities)
        assertEquals(10,tvShowEntities.size)
    }
}